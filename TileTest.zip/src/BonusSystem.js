// Bonus System
var BonusSystem = 
{
	gameState: null,
	player: null,
	
	init: function()
	{
		// Get game state and player
		for (var i = 0; i < ECSManager.entities.length; i++)
		{
			if (ECSManager.hasComponent(ECSManager.entities[i], ComponentType.COMPONENT_GAMESTATE))
			{
				this.gameState = ECSManager.getComponent(ECSManager.entities[i], ComponentType.COMPONENT_GAMESTATE);
			}
			
			if (ECSManager.hasComponent(ECSManager.entities[i], ComponentType.COMPONENT_PLAYER))
			{
				this.player = ECSManager.entities[i];
			}
		}
	},
	
	update: function(dt)
	{
		var playerPos = ECSManager.getComponent(this.player, ComponentType.COMPONENT_POSITION).position;
		var playerBox = ECSManager.getComponent(this.player, ComponentType.COMPONENT_BOX);
		
		for (var i = 0; i < ECSManager.entities.length; i++)
		{
			var ent = ECSManager.entities[i];
			
			if (ECSManager.hasComponent(ent, ComponentType.COMPONENT_LIFEBONUS))
			{
				var entPos = ECSManager.getComponent(ent, ComponentType.COMPONENT_POSITION).position;
				var entBox = ECSManager.getComponent(ent, ComponentType.COMPONENT_BOX);
				
				if (Utils.rectCollision(playerPos, entPos, playerBox, entBox))
				{
					this.gameState.lives += 1;
					ECSManager.removeEntity(ent);
					continue;
				}
			}
			else if (ECSManager.hasComponent(ent, ComponentType.COMPONENT_GOLDBONUS))
			{
				var entPos = ECSManager.getComponent(ent, ComponentType.COMPONENT_POSITION).position;
				var entBox = ECSManager.getComponent(ent, ComponentType.COMPONENT_BOX);
				
				if (Utils.rectCollision(playerPos, entPos, playerBox, entBox))
				{
					this.gameState.golds += 100;
					ECSManager.removeEntity(ent);
					continue;
				}
			}
		}
	}
}