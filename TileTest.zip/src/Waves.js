// Waves Data
var WAVES =
{
	"waves":
	[
		// First wave..
		[
			[
				"0",
				"20-orc",
				"10-phantom",
				"40-zombie",
				"10-werewolf"
			]
		],
		
		// Second wave..
		[
			[
				"0",
				"10-vampire",
				"20-skeleton"
			]
		],
		
		[
			[
				"0",
				"10-phantom",
				"30-rogue"
			]
		]
	]
}