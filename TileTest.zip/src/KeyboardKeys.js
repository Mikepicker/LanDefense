// Key-ASCII Table
var KeyboardKeys =
{
	PAUSE:	80,
	
	UP:		38,
	LEFT:	37,
	DOWN:	40,
	RIGHT:	39,
	
	W:		87,
	A:		65,
	S:		83,
	D:		68
}