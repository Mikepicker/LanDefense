// Each Entity is just an ID
var Entity =
{
	ID: 0
};